package com.escolaesportes.escoladeesportes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EscoladeesportesApplicationTests {

	@Test
	void contextLoads() {
	}

}
