package com.escolaesportes.emscolasdeesportes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.escolaesportes.entities")
public class EscoladeesportesApplication {

	public static void main(String[] args) {
		SpringApplication.run(EscoladeesportesApplication.class, args);
	}
}
